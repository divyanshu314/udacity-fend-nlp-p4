import { handleSubmit } from './formHandler'

describe('The function "handleSubmit()" should exist' , () => {
    test('It should be defined', () => {
        expect(handleSubmit).toBeDefined();
    });
});
