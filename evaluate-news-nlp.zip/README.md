# FEND ND Project 4; Evaluate a News Article with Natural Language Processing

The goal of this project is to give a practice with:
- Setting up Webpack
- Sass styles
- Webpack Loaders and Plugins
- Creating layouts and page design
- Service workers
- Using APIs and creating requests to external urls